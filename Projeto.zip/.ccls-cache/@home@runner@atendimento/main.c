#include <stdio.h>
#include <stdlib.h>

typedef struct{
  int dado;
  struct NO *prox;
} NO;

typedef struct{
  NO *ini;
  NO *fim;
} Fila;

void inicializarFila(Fila *f){
  f->ini = NULL;
  f->fim = NULL;
}

void enqueue(Fila *f, int dado){
  NO *ptr = (NO *) malloc(sizeof(NO)); //ponteiro auxiliador
  if (ptr == NULL){ //verificando se a memória foi alocada
    printf("Erro de alocação!!");
  } else {
    ptr->dado = dado; //armazena o dado
    ptr->prox = NULL; //ponteiro do novo nó aponta para NULL
    if (f->ini == NULL){ //verifica se a fila está vazia
      f->ini = ptr; //insere no inicio
    } else {
      f->fim->prox = ptr; //insere no fim
    }
    f->fim = ptr; //o fim da fila passa a ser o novo nó
  }

  return;
}

int dequeue(Fila *f){
  NO *ptr = f->ini; //ponteiro auxiliador
  int atual; //variavel que armazena o valor do nó atual
  if (ptr != NULL){ //verifica se a fila não está vazia
    f->ini = ptr->prox; //o inicio da fila deixa de apontar p/ o nó atual
    ptr->prox = NULL; //o ponteiro do nó atual aponta para NULL, o desconectando totalmente da fila
    atual = ptr->dado; //armazena o valor do nó atual
    free(ptr); //libera a memória do nó atual
    if (f->ini == NULL){ //verifica se a fila ficou vazia
      f->fim = NULL; //fim da fila aponta para NULL, indicando não haver mais nada na fila
    }
    printf("Removendo: %d da fila\n\n", atual);
    return atual;
  } else { //fila vazia
    printf("A fila está vazia!");
    return -1;
  }
}

void imprimirFila(Fila *f){
  NO *ptr = f->ini;
  if (ptr != NULL){
    printf("Inicio --> ");
    while (ptr != NULL){
      printf("%d ", ptr->dado);
      ptr = ptr->prox;
    }
    printf("<-- Fim\n");
  } else {
    printf("A fila está vazia!");
    return;
  }
}

int main(void) {
  printf("Hello World\n");
  return 0;
}