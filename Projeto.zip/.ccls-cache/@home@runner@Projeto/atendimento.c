//bibliotecas utilizadas
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

//estruturas
typedef struct{
  int dia;
  int mes;
  int ano;
} Data;

typedef struct{
  char nome[200];
  int idade;
  char RG[200];
  Data entrada;
} Registro;

typedef struct Elista{
  Registro dados;
  struct Elista *proximo;
}Elista;

typedef struct Lista{
  int qtde;
  Elista *primeiro;
}Lista;

typedef struct Efila {
    struct Efila *anterior;
    Registro dados;
    struct Efila *proximo;
}Efila;

typedef struct {
    Efila  *head;
    Efila *tail;
    int qtde;
} Fila;

typedef struct EABB{
  Registro dados;
  struct EABB* esq;
  struct EABB* dir;
  struct EABB* pai;
} EABB;

typedef struct ABB{
  EABB* raiz;
  int qtde;
} ABB;

//nessa partes estão as declarações dos menus, pq algumas das funções chamam eles e todos os menus chamam o menu principal
int menu_principal(int escolha, Registro dados, Lista *l, Fila *f, ABB *arvore); //declaração da função menu_principal

int menu_cadastro(int escolha, Registro dados, Lista *l, Fila *f, ABB *arvore); //declaração da função menu_cadastro

int menu_atendimento(int escolha, Registro dados, Lista *l, Fila *f, ABB *arvore);
//declaração da função menu_atendimento

int menu_pesquisa(int escolha, Registro dados, Lista *l, Fila *f, ABB *arvore); //declaração da função menu_pesquisa

int menu_cs(int escolha, Registro dados, Lista *l, Fila *f, ABB *arvore); //declaração da função menu_cs

//funções da lista encadeada
Lista *inicializa_lista(){
  Lista *l = malloc(sizeof(Lista)); //aloca a memória para a lista
  l->primeiro = NULL; //como está inicializando a lista, o primeiro elemento da lista é nulo
  l->qtde = 0; //como está inicializando a lista, a lista está vazia então a quantidade é zero
  return l;
}

void inserir(Lista *l, Registro dados){
  Elista *novo = malloc(sizeof(Elista)); //aloca memoria para o novo elemento da lista

  //como a inserção deve ser feita sempre no inicio...
  novo->dados = dados; //a célula recebe os dados do paciente
  novo->proximo = l->primeiro; //o proximo elemento da lista recebe o primeiro elemento da lista
  l->primeiro = novo; //o primeiro elemento da lista recebe o novo elemento

  l->qtde++; //aumenta a quantidade da lista
}

void imprimir_nomes(Lista *l){
  printf("Esses são os pacientes cadastrados no nosso sistema: \n\n"); 
  sleep(1);

  Elista *atual = l->primeiro; //ponteiro que aponta para o primeiro elemento da lista

  while(atual != NULL){ //enquanto o atual for diferente de nulo, percorre toda a lista
    printf("\tPaciente: %s, deu entrada em: %d/%d/%d\n", atual->dados.nome, atual->dados.entrada.dia, atual->dados.entrada.mes, atual->dados.entrada.ano); //imprime o nome de todos os pacientes da lista e quando deram entrada no nosso hospital
    atual = atual->proximo; //atualiza o valor do atual enquanto percorre a lista
  }

  if (l->qtde == 0){ //verifica se a lista de cadastros está vazia
    printf("\tNão há cadastros de pacientes!!\n"); //se está, imprime a mensagem de aviso
  }
  printf("\n");
}

void remover(Lista *l) {
  if(l->primeiro == NULL){ //verifica se a lista está vazia
    printf("\tNão há nenhum paciente cadastrado ainda!!\n");
    return; //se sim, só retorna
  } else { //se não

    imprimir_nomes(l); //chama a função imprimir_nomes para mostrar os pacientes que estão cadastrados
    
    //pede o nome do paciente que vai ser removido
    printf("Informe o nome do paciente a ser removido: ");
    char nome[200]; //variável que recebe o nome do paciente que vai ter os dados removidos
    scanf("%199[^\n]", nome); //recebe o nome do paciente. como dados.nome pode receber nome e sobrenome %199[^\n] é usado pra salvar o nome digitado até o final ao invés de só até o primeiro espaço
    
    Elista *atual = l->primeiro; //cria um ponteiro que aponta para o primeiro elemento da lista, e será usado pra percorrer a lista
    Elista *anterior = NULL; //cria um ponteiro que aponta para o elemento anterior ao atual

    while(atual != NULL && strcmp(atual->dados.nome, nome) != 0){ //enquanto o atual for diferente de nulo e o nome do atual for diferente do nome de quem vai ter os dados removidos, percorre a lista toda
      anterior = atual; //o anterior recebe o atual
      atual = atual->proximo; //o atual recebe o próximo
    }

    if (atual == NULL){ //se atual for igual a nulo retorna, pois chegou no final da lista e não encontrou o paciente
      printf("\tNão há cadastros referentes a essa pessoa!!\n");
      return;
    }

    if (atual == l->primeiro) { //se o paciente que vai ser removido for o primeiro da lista
      l->primeiro = atual->proximo; //o ponteiro que aponta para o começo da lista recebe o próximo elemento
    } else { //se não for o primeiro
      anterior->proximo = atual->proximo; //o ponteiro que aponta para o elemento anterior ao atual recebe o próximo
    }

    printf("\n\nO cadastro do paciente %s foi removido!!\n", nome); //avisa que o paciente foi removido

    free(atual); //apaga o atual
    l->qtde--; //diminui a quantidade da lista
  }
}

void imprimir(Lista *l){
  if (l->qtde == 0){ //verifica se a lista está vazia
    printf("\tNão há nenhum paciente cadastrado ainda!!\n\n"); 
    return; //se sim, exibe a mensagem de aviso e retorna
  } else { //se não...
    
      printf("Exibindo lista de pacientes: \n\n");
      sleep(1);

      Elista *atual = l->primeiro; //ponteiro que aponta para o primeiro elemento da lista

      while(atual != NULL){ //enquanto o atual for diferente de nulo, percorre toda a lista
        printf("\tNome: %s | Idade: %d | RG: %s | Data de entrada: %d/%d/%d\n", atual->dados.nome, atual->dados.idade, atual->dados.RG, atual->dados.entrada.dia, atual->dados.entrada.mes, atual->dados.entrada.ano); //imprime os dados de todos os pacientes da lista
        atual = atual->proximo; //atualiza o valor do atual enquanto percorre a lista
    }
      printf("\n");
  }
}

void consultar(Lista *l){
  //a mesma lógica da função remover pode ser usada aqui, com a mudança sendo exibir os dados ao invés de remover

  if(l->primeiro == NULL){ //verifica se a lista está vazia
    printf("\nNão há nenhum paciente cadastrado ainda!!\n");
    return; //se sim, só retorna
  } else { //se não

    imprimir_nomes(l); //chama a função imprimir_nomes para mostrar os pacientes que estão cadastrados

    //pede o nome do paciente que vai ter os dados consultados
    printf("Informe o nome do paciente que deseja consultar os dados: ");
    char nome[200]; //variável que recebe o nome do paciente que vai ter os dados consultados
    scanf("%199[^\n]", nome); //recebe o nome do paciente. como dados.nome pode receber nome e sobrenome %199[^\n] é usado pra salvar o nome digitado até o final ao invés de só até o primeiro espaço
    
    Elista *atual = l->primeiro; //cria um ponteiro que aponta para o primeiro elemento da lista, e será usado pra percorrer a lista
    Elista *anterior = NULL; //cria um ponteiro que aponta para o elemento anterior ao atual

    while(atual != NULL && strcmp(atual->dados.nome, nome) != 0){ //enquanto o atual for diferente de nulo e o nome do atual for diferente do nome de quem vai ter os dados consultados, percorre a lista toda
      anterior = atual; //o anterior recebe o atual
      atual = atual->proximo; //o atual recebe o próximo
    }

    if (atual == NULL){ //se atual for igual a nulo retorna, pois chegou no final da lista e não encontrou o paciente
      printf("\n\tNão há cadastros referentes a essa pessoa!!\n");
      return;
    }

    printf("\n\tNome: %s | Idade: %d | RG: %s | Data: %d/%d/%d\n", atual->dados.nome, atual->dados.idade, atual->dados.RG, atual->dados.entrada.dia, atual->dados.entrada.mes, atual->dados.entrada.ano); //imprime os todos os dados do paciente

  }
}

void atualizar(Lista *l){
  //a mesma lógica usada nas funções remover e consultar pode ser usada aqui, já que precisa percorrer toda a lista até achar a pessoa que vai ter os dados atualizados

  if(l->qtde == 0){ //verifica se a lista está vazia
    printf("\tNão há nenhum paciente cadastrado ainda!!\n");
    return; //se sim, só retorna
  } else {//se não

    imprimir_nomes(l); //chama a função imprimir_nomes para mostrar os pacientes que estão cadastrados
    
    //pede o nome do paciente que vai ter os dados atualizados
    printf("Informe o nome do paciente que deseja atualizar os dados: ");
    char nome[200]; //variável que recebe o nome do paciente que vai ter os dados atualizados
    scanf("%199[^\n]", nome); //recebe o nome do paciente. como dados.nome pode receber nome e sobrenome %199[^\n] é usado pra salvar o nome digitado até o final ao invés de só até o primeiro espaço
    
    Elista *atual = l->primeiro; //cria um ponteiro que aponta para o primeiro elemento da lista, e será usado pra percorrer a lista
    Elista *anterior = NULL; //cria um ponteiro que aponta para o elemento anterior ao atual

    while(atual != NULL && strcmp(atual->dados.nome, nome) != 0){ //enquanto o atual for diferente de nulo e o nome do atual for diferente do nome de quem vai ter os dados atualizados, percorre a lista toda
      anterior = atual; //o anterior recebe o atual
      atual = atual->proximo; //o atual recebe o próximo
    }

    if (atual == NULL){ //se atual for igual a nulo retorna, pois chegou no final da lista e não encontrou o paciente
      printf("\n\tNão há cadastros referentes a essa pessoa!!\n");
      return;
    }

    int atualizar; //variável que recebe a opção escolhida pelo usuário
    printf("\n\tPaciente encontrado!!\n");
    sleep (1);
    system("clear");
    printf("\nQual dado gostaria de atualizar:\n\n"); //pergunta qual dado o usuário quer atualizar
    printf("\t1 - Nome\n");
    printf("\t2 - Idade\n");
    printf("\t3 - RG\n");
    printf("\t4 - Data de entrada\n\n");
    printf("Digite o número do que quer atualizar: "); //então pede a escolha do usuário
    scanf("%d", &atualizar); //e recebe a escolha do usuário
    getchar(); //armazena o enter para que não haja erro se for atualizar o nome

    if (atualizar == 1){
      printf("\t\nInforme o novo nome: ");
      scanf("%199[^\n]", atual->dados.nome); //atualiza o nome do paciente, ou seja, atual recebe o novo nome
    }
    if (atualizar == 2){
      printf("\t\nInforme a nova idade: ");
      scanf("%d", &atual->dados.idade); //atualiza a idade do paciente, ou seja, atual recebe a nova idade
    }
    if (atualizar == 3){
      printf("\t\nInforme o novo RG: ");
      scanf("%s", atual->dados.RG); //atualiza o RG do paciente, ou seja, atual recebe o novo RG
    }
    if (atualizar == 4){
      printf("\nInforme o novo dia do cadastro: ");
      scanf("%d", &atual->dados.entrada.dia);
      printf("Informe o novo mês do cadastro: ");
      scanf("%d", &atual->dados.entrada.mes);
      printf("Iforme o novo ano do cadastro: ");
      scanf("%d", &atual->dados.entrada.ano); //atualiza a data de entrada do paciente, ou seja, atual recebe as novas datas
    }

    printf("\n\nOs dados do paciente %s foram atualizados com sucesso!!\n", nome); //avisa que a atualização foi feita

  }  
}

void cadastrar(Lista *l){
  Registro dados;

  system("clear");

  //pergunta as informações do paciente para salvar na lista
  printf("Informe os dados do paciente:\n\n");
  printf("\tNome: ");
  scanf("%200[^\n]", dados.nome); //recebe o nome do paciente, dados.nome pode receber tanto só o primeiro nome quanto o sobrenome, por isso o %200[^\n] é utilizado, ele salva o nome digitado até o final ao invés de só até o primeiro espaço
  printf("\tIdade: ");
  scanf("%d", &dados.idade); //recebe a idade do paciente
  printf("\tRG: ");
  scanf("%s", dados.RG); //recebe o RG do paciente
  printf("\tDia do cadastro: ");
  scanf("%d", &dados.entrada.dia); //recebe o dia de entrada do paciente
  printf("\tMês do cadastro: ");
  scanf("%d", &dados.entrada.mes); //recebe o mês de entrada do paciente
  printf("\tAno do cadastro: ");
  scanf("%d", &dados.entrada.ano); //recebe o ano de entrada do paciente

  printf("\n\nPaciente %s foi cadastrado!!\n", dados.nome); //avisa que o paciente foi cadastrado


  inserir(l, dados); //finalmente insere o paciente na lista de cadastros
}


//funções da fila
Fila *cria_Fila(){
  Fila *f = malloc(sizeof(Fila)); //aloca memória para a fila
    f->head = NULL; //como está inicializando a fila, o começo da fila aponta pro nulo
    f->tail = NULL; //como está inicializando a fila, o final da fila aponta pro fica nulo
    f->qtde = 0; //como está inicializando a fila, a fila está vazia então a quantidade é zero
    return f; //retorna a fila
}

Efila *criar_Efila(Registro dados){
    Efila *e = malloc(sizeof(Efila)); //aloca memória para a cécula da fila
    e->anterior = NULL; //como a célula está sendo criada agora, o seu anterior é nulo
    e->dados = dados; //a célula vai receber os dados do paciente
    e->proximo = NULL; ////como a célula está sendo criada agora, o seu próximo também é nulo
    return e; //retorna a célula
}

void enqueue(Fila *f, Registro dados){
    Efila *nova = criar_Efila(dados); //cria uma célula nova para a fila

    if(f->qtde == 0){ //se a quantidade da fila for igual a zero, a fila está vazia e a célula entra no começo
        f->head = nova; //o começo da fila passa a apontar pra nova célula
        f->tail = nova; //o final da fila também passa a apontar pra nova célula     
    } else { //se a quantidade não for zero, já tem paciente na fila e a nova célula entra no final, então...
        nova->anterior = f->tail; //o anterior da nova célula passa a apontar pro final da fila
        f->tail->proximo = nova; //o próximo do final da fila passa a apontar pra nova célula
        f->tail = nova; //e o final da fila recebe a cécula nova
    }

    f->qtde++; //então aumenta a quantidade da fila
}

void dequeue(Fila *f){
  if(f->qtde ==0){ //checa se a fila está vazia
    printf("\nNão há mais pacientes na fila de espera!!\n");
    return; //se estiver então os pacientes já foram atendidos ou ainda não foi inserido paciente na fila, então exibe a mensagem de aviso e retorna
  }

  //se não estiver vazia, então...
  Registro dados = f->head->dados; //cria uma variável que recebe os dados do paciente que vai ser atendido, ou seja, o paciente que está no começo da fila
  Efila *end = f->head; //cria uma variável auxiliar que aponta para o primeiro paciente da fila

  if(f->qtde == 1){ //se a quantidade da fila for igual a um, só tem um paciente na fila, então...
      f->head = NULL; //o começo da fila aponta pra nulo
      f->tail = NULL; //o final da fila aponta pra nulo também
  } else { //se não, tem mais de um paciente na fila, então...
    f->head->proximo->anterior = NULL; //o anterior do próximo do começo da fila aponta pra nulo
    f->head = f->head->proximo; //o começo da fila aponta pra o próximo da fila
  }

  free(end); //então apaga a cécula referente ao paciente
  f->qtde--; //e diminui a quantidade da fila

}

void imprimir_fila(Fila *f){
  if (f->qtde == 0){ //se a quantidade da fila for zero...
    printf("\tNão há pacientes na fila de espera!!\n\n");
    return; //signiica que não há pacientes na fila, então exibe a mensagem de aviso e retorna
  } else { //se não for zero, tem pacientes na fila, então...
      printf("Exibindo fila de espera: \n\n");
      sleep(1);
      Efila *atual = f->head; //cria um ponteiro auxiliar que aponta pro começo da fila
      int ordem = 0; //cria uma variavel para mostrar a ordem de posição dos pacientes na fila
    
      while(atual != NULL){ //enquanto atual for diferente de nulo, percorre toda a fila
        ordem++; //aumenta o valor da ordem em 1
        printf("\t%d° paciente a ser atendido: %s\n", ordem, atual->dados.nome); //mostra a posição do paciente na fila e o seu nome
        atual = atual->proximo; //atualiza o valor do atual
    }
    
    printf("\n");
  }
}

void verifica(Fila *f, Lista *l, Registro dados){
  imprimir_nomes(l);//chama a função imprimir_nomes para mostrar os pacientes que estão cadastrados
  
  printf("Informe o nome do paciente que deseja por na fila de espera: ");
  char nome[200]; //variável que recebe o nome do paciente para checar se existe no sistema
  scanf("%199[^\n]", nome); //recebe o nome do paciente. como dados.nome pode receber nome e sobrenome %199[^\n] é usado pra salvar o nome digitado até o final ao invés de só até o primeiro espaço

  Elista *atual = l->primeiro; //cria um ponteiro que aponta para o primeiro elemento da lista, e será usado pra percorrer a lista
  Elista *anterior = NULL; //cria um ponteiro que aponta para o elemento anterior ao atual

  while(atual != NULL && strcmp(atual->dados.nome, nome) != 0){ //enquanto o atual for diferente de nulo e o nome do atual for diferente do nome de quem vai entrar na fila de espera, percorre a lista toda
    anterior = atual; //o anterior recebe o atual
    atual = atual->proximo; //o atual recebe o próximo
  }

  if(atual != NULL){ //se atual for diferente de nulo, significa que o paciente possui cadastro
    
    Efila *atual_fila = f->head; //cria um ponteiro auxiliar que aponta pro começo da fila
    
      while(atual_fila != NULL && strcmp(atual_fila->dados.nome, nome) != 0){ //enquanto atual for diferente de nulo, percorre toda a fila para ver se o paciente já não está na fila de espera
        atual_fila = atual_fila->proximo; //atualiza o valor do atual
    }
    if (atual_fila != NULL){ //se o atual da fila for diferente de nulo, significa que o paciente já está na fila de espera
      printf("\nEsse paciente já está na fila de espera!!\n");
    } else { //se não, significa que ele não está na fila e pode entrar nela
      enqueue(f, atual->dados); //então adiona o paciente na fila de espera
      printf("\n\nPaciente %s será o %d° a ser atendido!!\n", nome, f->qtde);
    }
    
  } else { //se não, significa que o paciente não possui cadastro e não pode entrar na fila de espera
    printf("\nEsse paciente não possui cadastro em nosso sistema!!\n");
  }
}


//funções da ABB
EABB *cria_vertice(ABB *arvore, Registro dados){
  EABB* novo = malloc(sizeof(EABB)); //aloca memória para o vértice novo
  //como o vértice novo está sendo criado agora, as folhas da direita, da esquerda e o pai são nulas
  novo->dir = NULL; 
  novo->esq = NULL;
  novo->pai = NULL;
  novo->dados = dados; //o vértice recebe os dados do paciente
  return novo; //retorna o vértice novo
}

ABB *cria_arvore(){
  ABB* arvore = malloc(sizeof(ABB)); //aloca memória para a árvore
  arvore->raiz = NULL; //como a árvore está sendo criada agora, a raiz dela é nula
  arvore->qtde = 0; //e não tem nada na árvora, então a quantidade é zero
  return arvore; //retorna a árvore
}

void inserir_ABB(ABB* arvore, Registro dados, int escolha){

  if (escolha == 1){ //se a escolha no menu de pesquisa for 1, insere na árvore binária de busca tendo os valores dos anos de entrada como referência
    EABB * novo = cria_vertice(arvore, dados); //cria um novo nó com os dados do paciente

    if(arvore->raiz == NULL){ //se a raiz da árvore for nula...
      arvore->raiz = novo; //a raiz da árvore recebe o novo nó
      arvore->qtde++; //aumenta a quantidade da árvore
    } else { //se a raiz não for nula...
      EABB *atual = arvore->raiz; //cria um ponteiro auxiliar que aponta para a raiz da árvore
      EABB *pai = NULL; //cria um ponteiro que aponta para o pai do atual

      while(atual != NULL){ //roda pela árvore enquanto o atual não for nulo procurando um local para inserir o novo nó
        pai = atual; //atualiza o valor do pai

        if(novo->dados.entrada.ano < atual->dados.entrada.ano){ //se o ano de entrada do novo paciente for menor que o ano de entrada do paciente atual na lista, vai para a esquerda
          atual = atual->esq;
        } else { //se for maior, vai para a direita
          atual = atual->dir;
        }
      }

      novo->pai = pai; //o pai do novo nó recebe o pai do atual

      if(novo->dados.entrada.ano < pai->dados.entrada.ano){ //se o ano de entrada do novo paciente for menor que o ano de entrada do pai, vai para a esquerda
        pai->esq = novo;
      } else { //se for maior, vai para a direita
        pai->dir = novo;
      }
      arvore->qtde++;
    }     
  }
  if (escolha == 2){ //se a escolha no menu de pesquisa for 2, insere na árvore binária de busca tendo os valores dos meses de entrada como referência    
    EABB * novo = cria_vertice(arvore, dados); //cria um novo nó com os dados do paciente

    if(arvore->raiz == NULL){ //se a raiz da árvore for nula...
      arvore->raiz = novo; //a raiz da árvore recebe o novo nó
      arvore->qtde++; //aumenta a quantidade da árvore
    } else { //se a raiz não for nula...
      EABB *atual = arvore->raiz; //cria um ponteiro auxiliar que aponta para a raiz da árvore
      EABB *pai = NULL; //cria um ponteiro que aponta para o pai do atual

      while(atual != NULL){ //roda pela árvore enquanto o atual não for nulo procurando um local para inser
        pai = atual; //atualiza o valor do pai

        if(novo->dados.entrada.mes < atual->dados.entrada.mes){ //se o mês de entrada do novo paciente for menor que o mês de entrada do paciente atual na lista, vai para a esquerda
          atual = atual->esq;
        } else { //se for maior, vai para a direita
          atual = atual->dir;
        }
      }

      novo->pai = pai; //o pai do novo nó recebe o pai do atual

      if(novo->dados.entrada.mes < pai->dados.entrada.mes){ //se o mês de entrada do novo paciente for menor que o mês de entrada do pai, vai para a esquerda
        pai->esq = novo;
      } else { //se for maior, vai para a direita
        pai->dir = novo;
      }
      arvore->qtde++;
    }
  }
  if (escolha == 3){ //se a escolha no menu de pesquisa for 3, insere na árvore binária de busca tendo os valores dos dias de entrada como referência    
    EABB * novo = cria_vertice(arvore, dados); //cria um novo nó com os dados do paciente

    if(arvore->raiz == NULL){ //se a raiz da árvore for nula...
      arvore->raiz = novo; //a raiz da árvore recebe o novo nó
      arvore->qtde++; //aumenta a quantidade da árvore
    } else { //se a raiz não for nula...
      EABB *atual = arvore->raiz; //cria um ponteiro auxiliar que aponta para a raiz da árvore
      EABB *pai = NULL; //cria um ponteiro que aponta para o pai do atual

      while(atual != NULL){ //roda pela árvore enquanto o atual não for nulo procurando um local para inser
        pai = atual; //atualiza o valor do pai

        if(novo->dados.entrada.dia < atual->dados.entrada.dia){ //se o dia de entrada do novo paciente for menor que o dia de entrada do paciente atual na lista, vai para a esquerda
          atual = atual->esq;
        } else { //se for maior, vai para a direita
          atual = atual->dir;
        }
      }

      novo->pai = pai; //o pai do novo nó recebe o pai do atual

      if(novo->dados.entrada.dia < pai->dados.entrada.dia){ //se o dia de entrada do novo paciente for menor que o dia de entrada do pai, vai para a esquerda
        pai->esq = novo;
      } else { //se for maior, vai para a direita
        pai->dir = novo;
      }
      arvore->qtde++;
    }
  }
  if (escolha == 4){ //se a escolha no menu de pesquisa for 4, insere na árvore binária de busca tendo os valores das idades como referência    
    EABB * novo = cria_vertice(arvore, dados); //cria um novo nó com os dados do paciente

    if(arvore->raiz == NULL){ //se a raiz da árvore for nula...
      arvore->raiz = novo; //a raiz da árvore recebe o novo nó
      arvore->qtde++; //aumenta a quantidade da árvore
    } else { //se a raiz não for nula...
      EABB *atual = arvore->raiz; //cria um ponteiro auxiliar que aponta para a raiz da árvore
      EABB *pai = NULL; //cria um ponteiro que aponta para o pai do atual

      while(atual != NULL){ //roda pela árvore enquanto o atual não for nulo procurando um local para inser
        pai = atual; //atualiza o valor do pai

        if(novo->dados.idade < atual->dados.idade){ //se a idade do novo paciente for menor que a idade do paciente atual na lista, vai para a esquerda
          atual = atual->esq;
        } else { //se for maior, vai para a direita
          atual = atual->dir;
        }
      }

      novo->pai = pai; //o pai do novo nó recebe o pai do atual

      if(novo->dados.idade < pai->dados.idade){ //se a idade do novo paciente for menor que a idade do pai, vai para a esquerda
        pai->esq = novo;
      } else { //se for maior, vai para a direita
        pai->dir = novo;
      }
      arvore->qtde++;
    }
  }
}

int remover_vertice(ABB* arvore, EABB* vertice){
  if (arvore->raiz == NULL){ //se a raiz da arvore é nula, significa que ela está vazia
    return 0;
  }

  int filhos; //cria uma variável pra fazer a verificação de filhos
  //checa quantidade de folhas
  if (vertice->esq == NULL && vertice->dir == NULL){
    filhos = 0; //é folha ou raiz sozinha
  }
  if (vertice->esq != NULL || vertice->dir != NULL){
    filhos = 1; //é galho com uma folha
  }
  if (vertice->esq != NULL && vertice->dir != NULL){
    filhos = 2; //é galho com duas folhas
  }

  if (filhos == 0){ //se é folha ou raiz sozinha
    if (vertice->pai == NULL){ //vê se é a raiz ou uma folha comparando com o pai
      arvore->raiz = NULL; //se é pai, então a raiz é nula
    } else { //se não for pai
      if (vertice->pai->esq == vertice){ //checa se é folha esquerda ou direito
        vertice->pai->esq = NULL; //remove a folha esquerda
      } else {
        vertice->pai->dir = NULL; //remove a folha direita
      }
    }
    free(vertice); //remove folha
    arvore->qtde--;
    return 1;

  } else {
    if (filhos == 1){ //remove galhos com uma folha
      EABB *aux; //variavel auxiliar
      if(vertice->esq != NULL){ //checa se só tem folha na esquerda
        aux = vertice->esq; //guarda oq vai ser trocado
        vertice->dados.idade = vertice->esq->dados.idade; //troca a folha da esquerda com oq vai ser removido
        vertice->dados = aux->dados; //vertice recebe o valor da troca
        remover_vertice(arvore, vertice->esq); //chama a função com referência da folha
        arvore->qtde--;
      } else { //mesma coisa, mas pra direita
        aux = vertice->dir; 
        vertice->dados.idade = vertice->dir->dados.idade;
        vertice->dados = aux->dados;
        remover_vertice(arvore, vertice->dir);
        arvore->qtde--;
      }
    } else {
      EABB *aux; //variavel auxiliar
      Registro atual; //variavel pra troca
      aux = vertice->esq; //vai pro galho da esquerda
      while(aux->dir != NULL){ //depois procura a folha mais a direita
        aux = aux->dir; //vai atualizando a posição
      }
      atual = aux->dados; //guarda o valor da folha mais a direita
      aux->dados = vertice->dados; //folha mais a direita recebe o valor que vai ser removido
      vertice->dados = atual; //valor que vai ser removido recebe o valor da folha mais a direita
      remover_vertice(arvore, aux); //chama a função com referência da folha mais a direita
      arvore->qtde--;
    }
  }
  return 0;  
}

void apaga_ABB(ABB* arvore){
  while(arvore->raiz != NULL){ //enquanto a raiz não for nula, chama a função de remover para limpar a árvore
    remover_vertice(arvore, arvore->raiz);
  }
}

void in_ordem(EABB * raiz) {
  //imprime os valores da árvore em ordem do menor para o maior
  if (raiz){ //se a raiz não for nula
    in_ordem(raiz->esq); //chama a função com referência a esquerda
    printf("\tNome: %s | Idade: %d | RG: %s | Data de entrada: %d/%d/%d\n", raiz->dados.nome, raiz->dados.idade, raiz->dados.RG, raiz->dados.entrada.dia, raiz->dados.entrada.mes, raiz->dados.entrada.ano); //imprime os dados
    in_ordem(raiz->dir); //chama a função com referência a direita
  }
}

void pesquisa(Lista *l, ABB* arvore, Fila *f, Registro dados, int escolha){
  int sair; //variavel criada para sair do menu de cadastro, já que um sleep não ia ser a melhor opção para esse caso

  if (l ->qtde == 0){ //se a lista de cadastros estiver vazia, não há oq pesquisar, então retorna para o menu de pesquisa
    system("clear");
    printf("\tNão há pacientes cadasatrados ainda!!\n");
    sleep(2);
    menu_pesquisa(escolha, dados, l, f, arvore);
  }

  sleep(1); //aguarda 1 segundo para mostrar os cadastros
  
  Elista *atual = l->primeiro; //ponteiro que aponta para o primeiro elemento da lista
  while(atual != NULL){ 
    inserir_ABB(arvore, atual->dados, escolha);
    atual = atual->proximo; //atualiza o valor do atual enquanto percorre a lista
  }

  in_ordem(arvore->raiz); //chama a função de impressão da árvore

  while(sair != 1){ //enqunto a variavel sair for diferente de 1, ele continua na tela e mostra a mensagem de sair de novo
    printf("\nDigite 1 para sair: ");
    scanf("%d", &sair);
  }

  if (sair == 1){ //se for igual a 1, volta pro menu de cadastro
    apaga_ABB(arvore); //chama a função de apagar a árvore antes de voltar para o menu, para limpar a árvore para a próxima pesquisa, assim os dados não são inseridos mais de uma vez
    menu_pesquisa(escolha, dados, l, f, arvore);
  }  
}


//funções relecionadas ao arquivo
void inverter(Registro dados, Lista *l){
  //como para carregar a lista a ordem de insersção deve ser mantida, essa função foi criada pra inverter os dados do arquivo para inserir na lista na ordem certa
  
  Elista *novo = malloc(sizeof(Elista)); //aloca memoria para o novo elemento da lista
  novo->dados = dados; //a célula recebe os dados do paciente
  novo->proximo = NULL; //o proximo elemento da lista recebe o primeiro elemento da lista

  if (l->qtde == 0){ //se a lista estiver vazia...
    l->primeiro = novo; //insere no começo mesmo
  } else { //se ela não estiver vazia...
    
    Elista *atual = l->primeiro; //cria um ponteiro auxiliar, que aponta pro começo da lista
    Elista *anterior = NULL; //cria outro ponteiro auxiliar, que aponta pro anterior da célula atual

    while(atual != NULL){ //roda a lista até o final
      anterior = atual; //atualiza o valor do anterior, com o atual
      atual = atual->proximo; //atualiza o valor do atual, com o próximo
    }

    anterior->proximo = novo; //o próximo do anterior vai recever o novo elemento
  }

  l->qtde++; //aumenta a quantidade da lista
}

void carregar(Registro dados, Lista *l){
  if (l->qtde > 0){ //verifica se a lista já cadastros já não está carregada
    //caso esteja, exibe a mensagem de aviso e retorna pro menu de carrgar/salvar
    printf("\tA lista de cadastros já está carregada!!\n");
    sleep(3);
    return;
  } else if (l->qtde == 0){ //se a lista não estiver carregada...

    FILE *registros; //cria um ponteiro para o arquivo de texto
    registros = fopen("pacientes.txt", "r"); //procura o arquivo de texto no modo de leitura "r"

    while (!feof(registros)){ //lê o arquivo enquanto não chegar em um nulo
      fscanf(registros, "Nome: %199[^|] | Idade: %d | RG: %199[^|] | Data de entrada: %d/%d/%d\n", dados.nome, &dados.idade, dados.RG, &dados.entrada.dia, &dados.entrada.mes, &dados.entrada.ano); //lê as informações do arquivo de texto...
      //como o dados.nome pode receber nome e sobrenome, o %199[^|] é usado para ler até a primeira "|", que é onde o nome termina 
      inverter(dados, l); //e então salva elas na lista de cadastros, mantendo a ordem de inserção
    }

    fclose(registros); //fecha o arquivo
  }
  
  printf("\tCarrengando lista de cadastros...\n");
  sleep(3);
}

void salvar(Registro dados, Lista *l){
  FILE *registros; //cria um ponteiro para o arquivo de texto
  registros = fopen("pacientes.txt", "w"); //abre o arquivo e apaga oq tem nele
  fclose(registros); //fecha o arquivo
  
  registros = fopen("pacientes.txt", "r+"); //abre novamente, mas no modo de escrita

  Elista *atual = l->primeiro; //ponteiro que aponta para o primeiro elemento da lista

  while(atual != NULL){ 
    fprintf(registros, "Nome: %s| Idade: %d| RG: %s| Data de entrada: %d/%d/%d\n", atual->dados.nome, atual->dados.idade, atual->dados.RG, atual->dados.entrada.dia, atual->dados.entrada.mes, atual->dados.entrada.ano); //antes de salvar na lista, salva as informações no arquivo de texto
    atual = atual->proximo; //atualiza o valor do atual enquanto percorre a lista
  }

  fclose(registros); //fecha o arquivo
}


//menus
int menu_principal(int escolha, Registro dados, Lista *l, Fila *f, ABB *arvore){
  system("clear");

  FILE *registros; //cria um ponteiro para o arquivo de texto
  registros = fopen("pacientes.txt", "r"); //procura o arquivo de texto no modo de leitura "r"
  if (registros==NULL) { //caso o arquivo não tenha sido criado, cria ele
    registros = fopen("pacientes.txt", "w+"); //cria o arquivo
  }

  fclose(registros); //fecha o arquivo

  printf("O que deseja fazer?\n\n");

  printf("\t1 - Acessar o menu de cadastro\n");
  printf("\t2 - Acessar o menu de atendimento\n");
  printf("\t3 - Realizar uma pesquisa\n");  
  printf("\t4 - Carregar ou salvar o arquivo\n");  
  printf("\t5 - Acessar as nossas informações sobre\n"); 
  printf("\t6 - Encerrar o programa\n\n");

  printf("Digite o número de sua escolha: ");
  scanf("%d", &escolha);

  do{  
    switch(escolha){
      case 1:
        system("clear");
        printf("Acessando menu de cadastro...\n");
        sleep(3);
        menu_cadastro(escolha, dados, l, f, arvore);
        break;

      case 2:
        system("clear");
        printf("Acessando menu de atendimento...\n");
        sleep(3);
        menu_atendimento(escolha, dados, l, f, arvore);
        break;

      case 3:
        system("clear");
        printf("Acessando menu de pesquisa...\n");
        sleep(3);
        menu_pesquisa(escolha, dados, l, f, arvore);
        break;

      case 4:
        system("clear");
        printf("Acessando menu de carregamento ou salvamento...\n");
        sleep(3);
        menu_cs(escolha, dados, l, f, arvore);
        break;

      case 5:
        system("clear");
        printf("Exibindo nossas informações...\n");
        sleep(3);
        system("clear");
        printf("Leonardo Quirino | 11.121.422-7 | Engenharia de Robôs\nMatheus Kenji | 11.121.088-6 | Engenharia de Robôs\n\n");
        int sair; //variavel criada para sair do menu de cadastro, já que um sleep não ia ser a melhor opção para esse caso

        while(sair != 1){ //enqunto a variavel sair for diferente de 1, ele continua na tela e mostra a mensagem de sair de novo
          printf("\nDigite 1 para sair: ");
          scanf("%d", &sair);
        }

        if (sair == 1){ //se for igual a 1, volta pro menu principal
          menu_principal(escolha, dados, l, f, arvore);
        }
        
        break;

      case 6:
        system("clear");
        printf("\tEncerrando em...\n");
            sleep(1);
            printf("\t3...\n");
            sleep(1);
            printf("\t2...\n");
            sleep(1);
            printf("\t1...\n");
            sleep(1);
            //após os 3 segundos e as mensagens de aviso, encerra o programa
            exit(0);

          default: //caso o usuário digite um número que não está no menu, ele volta pro menu principal
            printf("Opção inválida!!\n");
            sleep(3);
            menu_principal(escolha, dados, l, f, arvore);
            break;
          } 
        } while(escolha != 6); //enquanto a escolha for diferente de 6, continua rodando o menu de cadastro

  return escolha; //retorna o valor da escolha
}

int menu_cadastro(int escolha, Registro dados, Lista *l, Fila *f, ABB *arvore){
  system("clear"); //limpa o terminal

  printf("Área de cadastro\n\n");
  printf("O que deseja fazer?\n\n");

  printf("\t1 - Cadastrar um paciente\n");
  printf("\t2 - Consultar um cadastro\n");
  printf("\t3 - Ver lista de cadastros\n");
  printf("\t4 - Atualizar dados\n");
  printf("\t5 - Remover um cadastro\n");
  printf("\t6 - Retornar ao menu principal\n\n");

  printf("Escolha uma opção: "); //pede a escolha do usuário
  scanf("%d", &escolha); //recebe a escolha do usuário
  getchar(); //armazena o enter para que não haja erro nas funções

  do{  //enquanto a escolha for diferente de 6, continua rodando o menu de cadastro
  switch(escolha){
    case 1: //se a escolha for 1...

      if (l->qtde == 0){ //verifica se a lista de cadastros está vazia
        system("clear");
        carregar(dados, l); //se está, checa o arquivo e carrega os dados na lista. é feito isso para o caso de esquecer de carregar os dados na lista e evitar que ao salvar o arquivo depois, não seja perdido oq já estava no arquivo
      }

      system("clear"); //limpa o terminal

      cadastrar(l); //chama a função de cadastro

      sleep(3); //aguarda 3 segundos...

      menu_cadastro(escolha, dados, l, f, arvore); //volta pro menu de cadastro

      break; //encerra o caso

    case 2:
      system("clear"); //limpa o terminal

      consultar(l); //chama a função de consulta

      int sair; //variavel criada para sair do menu de cadastro, já que um sleep não ia ser a melhor opção para esse caso

      while(sair != 1){ //enqunto a variavel sair for diferente de 1, ele continua na tela e mostra a mensagem de sair de novo
        printf("\nDigite 1 para sair: ");
        scanf("%d", &sair);
      }

      if (sair == 1){ //se for igual a 1, volta pro menu de cadastro
        menu_cadastro(escolha, dados, l, f, arvore);
      }

      break;

    case 3:
      system("clear");

      imprimir(l); //chama a função imprimir, para mostrar todos os pacientes cadastrados até o momento

      while(sair != 1){ //enqunto a variavel sair for diferente de 1, ele continua na tela e mostra a mensagem de sair de novo
        printf("Digite 1 para sair: ");
        scanf("%d", &sair);
      }

      if (sair == 1){ //se for igual a 1, volta pro menu de cadastro
        menu_cadastro(escolha, dados, l, f, arvore);
      }

      break;

    case 4:
      system("clear"); //limpa o terminal

      atualizar(l); //chama a função de atualizar 

      sleep(3); //espera 3 segundos...

      menu_cadastro(escolha, dados, l, f, arvore); //então volta pro menu de cadastro

      break;

    case 5:
      system("clear"); //limpa o terminal

      remover(l); //chama a função de remover

      sleep(3); //espera 3 segundos...

      menu_cadastro(escolha, dados, l, f, arvore); //então volta pro menu de cadastro

      break;

    case 6:
      system("clear"); //limpa o terminal

      printf("Retornando para o menu principal...\n");
      sleep(3);

      //após a mensagem de aviso e 3 segundos...
      menu_principal(escolha, dados, l, f, arvore); //chama a função menu principal

      break;

    default: //caso o usuário digite um número que não está no menu, ele volta pro menu de cadastro
      printf("Opção inválida\n");
      sleep(3);
      menu_cadastro(escolha, dados, l, f, arvore);
      break;
    } 
  } while(escolha != 6); //enquanto a escolha for diferente de 6, continua rodando o menu de cadastro

  return escolha; //retorna o valor da escolha

}

int menu_atendimento(int escolha, Registro dados, Lista *l, Fila *f, ABB *arvore){
  system("clear");

  int sala; //variavel criada para receber um número aleátorio para simular as salas de atendimento

  printf("Área de atendimento\n\n");
  printf("O que deseja fazer?\n\n");

  printf("\t1 - Adicionar um paciente à fila de espera\n");
  printf("\t2 - Chamar paciente\n");
  printf("\t3 - Ver fila de espera\n");
  printf("\t4 - Retornar ao menu principal\n\n");

  printf("Escolha uma opção: "); //pede a escolha do usuário
  scanf("%d", &escolha); //receve a escolha do usuário
  getchar(); //armazena o enter para que não haja erro nas funções

  do{ //enquanto a escolha for diferente de 4, continua rodando o menu de atendimento
    switch(escolha){
      case 1:
        system("clear");

        if (l ->qtde == 0){ //checa se a lista de cadastros está vazia
          printf("\tNão há nenhum paciente cadastrado ainda!!\n");
          sleep(2);
        } else { //se não está vazia...

          verifica(f, l, dados); //chama a função verifica, para ver se o nome digitado existe na lista de cadastro e adiciona na fila, se existir já é colocado na fila
        }

        sleep(3);
        menu_atendimento(escolha, dados, l, f, arvore); //volta pro menu de atendimento

        break;

      case 2:
        system("clear");

        if (f->qtde == 0){ //checa se a fila de espera está vazia
          printf("\tNão há nenhum paciente na fila de espera!!\n");
          sleep(2);
          menu_atendimento(escolha, dados, l, f, arvore); //volta pro menu de atendimento
        }

        sala = rand() % 15; //sorteia um número aleatório entre 0 e 14 para simular as salas de atendimento
        printf("\tPaciente %s, por favor vá até a sala %d para ser atendido!!\n", f->head->dados.nome, sala); //exibe o nome do paciente que vai ser desinfileirado
        dequeue(f); //desenfileira
        sleep(5);
        menu_atendimento(escolha, dados, l, f, arvore); //volta pro menu de atendimento
        break;

      case 3:
        system("clear");

        
        imprimir_fila(f); //após 1 segundo, chama a função imprimir_fila, para mostrar quem está na fila de espera

        int sair; //variavel criada para sair da impressão da fila de espera, já que um sleep não ia ser a melhor opção para esse caso

        while(sair != 1){ //enqunto a variavel sair for diferente de 1, ele continua na tela e mostra a mensagem de sair de novo
          printf("Digite 1 para sair: ");
          scanf("%d", &sair);
        }

        if (sair == 1){ //se for igual a 1, volta pro menu de cadastro
          menu_atendimento(escolha, dados, l, f, arvore);
        }
        break;

      case 4:
        system("clear");
        printf("Retornando para o menu principal...\n");
        sleep(3);
        menu_principal(escolha, dados, l, f, arvore); //volta pro menu principal após 3 segundos
        break;

      default: //caso o usuário digite um número que não está no menu, ele volta pro menu de atendimento
        printf("Opção inválida\n");
        sleep(3);
        menu_atendimento(escolha, dados, l, f, arvore);
        break;
    }
  }  while(escolha != 4); //enquanto a escolha for diferente de 4, continua rodando o menu de atendimento

  return escolha; //retorna o valor da escolha
}

int menu_pesquisa(int escolha, Registro dados, Lista *l, Fila *f, ABB *arvore){
  system("clear"); //limpa o terminal

  printf("Área de pesquisa\n\n");
  printf("O que deseja fazer?\n\n");

  printf("\t1 - Pesquisar por ano de entrada\n");
  printf("\t2 - Pesquisar por mês de entrada\n");
  printf("\t3 - Pesquisar por dia de entrada\n");
  printf("\t4 - Pesquisar por idade\n");
  printf("\t5 - Retornar ao menu principal\n\n");

  printf("Escolha uma opção: "); //pede a escolha do usuário
  scanf("%d", &escolha); //recebe a escolha do usuário

  do{ //enquanto a escolha for diferente de 5, continua rodando o menu de pesquisa
    switch(escolha){
      case 1:
        system("clear"); //limpa o terminal

        printf("Dados dos pacientes, exibidos com base no ano de entrada:\n\n");
        
        pesquisa(l, arvore, f, dados, escolha); //chama a função pesquisa
        
      break;

      case 2:
        system("clear");

        printf("Dados dos pacientes, exibidos com base no mês de entrada:\n\n");
        
        pesquisa(l, arvore, f, dados, escolha);//chama a função pesquisa
        
      break;

      case 3:
        system("clear");

        printf("Dados dos pacientes, exibidos com base no dia de entrada:\n\n");
        
        pesquisa(l, arvore, f, dados, escolha); //chama a função pesquisa
        
      break;

      case 4:
        system("clear");

        printf("Dados dos pacientes, exibidos em ordem do paciente mais novo ao mais velho:\n\n");
        
        pesquisa(l, arvore, f, dados, escolha); //chama a função pesquisa
        
      break;

      case 5:
        system("clear");
        printf("Retornando para o menu principal...\n");
        sleep(3);
        menu_principal(escolha, dados, l, f, arvore); //volta pro menu principal após 3 segundos
        break;

      default: //caso o usuário digite um número que não está no menu, ele volta pro menu de atendimento
      printf("Opção inválida\n");
      sleep(3);
      menu_pesquisa(escolha, dados, l, f, arvore);
      break;
    }
  } while(escolha != 5);

  return escolha;
}

int menu_cs(int escolha, Registro dados, Lista *l, Fila *f, ABB *arvore){
  system("clear"); //limpa o terminal

  printf("Área de atualização do arquivo\n\n");
  printf("O que deseja fazer?\n\n");
  printf("\t1 - Carregar a lista de cadastros de pacientes\n");
  printf("\t2 - Salvar as alterações no arquivo\n");
  printf("\t3 - Retornar ao menu principal\n\n");
  
  printf("Escolha uma opção: "); //pede a escolha do usuário
  scanf("%d", &escolha); //recebe a escolha do usuário

  do{
    switch(escolha){
      case 1:
        system("clear"); //limpa o terminal

        carregar(dados, l); //chama a função carregar

        menu_cs(escolha, dados, l, f, arvore); //volta pro menu de cadastro
        break; //encerra o caso

      case 2:
        system("clear"); //limpa o terminal
        salvar(dados, l); //chama a função salvar

        printf("\tArquivo atualizado com sucesso!!\n");
        sleep(3);

        menu_cs(escolha, dados, l, f, arvore); //volta pro menu de cadastro
        break; //encerra o caso

      case 3:
    system("clear"); //limpa o terminal

        printf("Retornando para o menu principal...\n");
        sleep(3);

        //após a mensagem de aviso e 3 segundos...
        menu_principal(escolha, dados, l, f, arvore); //chama a função menu principal

        break;

      default: //caso o usuário digite um número que não está no menu, ele volta pro menu de carregar/salvar
        printf("Opção inválida\n");
        sleep(3);
        menu_cs(escolha, dados, l, f, arvore);
        break;
      } 
    } while(escolha != 3); //enquanto a escolha for diferente de 3, continua rodando o menu de carregar/salvar

  return escolha; //retorna o valor da escolha
}


//main
int main(void) {
  Lista *l = inicializa_lista(); //inicializa a lista de cadastros
  Fila *f = cria_Fila(); //inicializa a fila de espera
  ABB *arvore = cria_arvore(); //inicializa a árvore binária de busca
  int escolha; //variavel criada para receber a escolha do usuário
  Registro dados; //variavel criada para receber os dados dos pacientes
  
  printf("***************** Bem-vindo ao nosso hospital *****************\n\n");

  printf("                      mm@@@@@@@@@@@@@@@@..\n");
  printf("                  MM@@@@@@@@@@@@@@@@@@@@@@@@..\n");
  printf("                @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
  printf("              @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
  printf("            @@@@@@@@@@@@@@::      MM@@@@@@@@@@@@@@MM\n");
  printf("          @@@@@@@@@@@@@@@@::      MM@@@@@@@@@@@@@@@@\n");
  printf("        ..@@@@@@@@@@@@@@@@::      MM@@@@@@@@@@@@@@@@@@\n");
  printf("        @@@@@@@@@@@@@@@@@@::      MM@@@@@@@@@@@@@@@@@@\n");
  printf("        @@@@@@@@@@@@@@@@@@::      MM@@@@@@@@@@@@@@@@@@@@\n");
  printf("        @@@@@@@@----------        ....--------@@@@@@@@@@\n");
  printf("      --@@@@@@@@                              @@@@@@@@@@\n");
  printf("      ..@@@@@@@@                              @@@@@@@@@@\n");
  printf("        @@@@@@@@                              @@@@@@@@@@\n");
  printf("        @@@@@@@@@@@@@@@@@@::      mm@@@@@@@@@@@@@@@@@@@@\n");
  printf("        @@@@@@@@@@@@@@@@@@--      MM@@@@##@@@@@@@@@@@@::\n");
  printf("        @@@@@@@@@@@@@@@@@@::      MM@@@@@@@@@@@@@@@@@@\n");
  printf("          @@@@@@@@@@@@@@@@::      MM@@@@@@@@@@@@@@@@@@\n");
  printf("          @@@@@@@@@@@@@@@@::      MM@@@@@@@@@@@@@@@@\n");
  printf("            @@@@@@@@@@@@@@::      MM@@@@@@@@@@@@@@..\n");
  printf("              @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@--\n");
  printf("                @@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
  printf("                  MM@@@@@@@@@@@@@@@@@@@@@@@@..\n");
  printf("                      mm@@@@@@@@@@@@@@@@..\n");
  
  sleep(3);

  menu_principal(escolha, dados, l, f, arvore); //abre o menu pricipal

  return 0;
}